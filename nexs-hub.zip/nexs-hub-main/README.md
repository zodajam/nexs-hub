nexs-hub is where all  the games made by me, rasz64 are. It's protected by a MIT license, which means that you can do this:

Use It Freely: You can use the code for personal or commercial projects without any worries. Want to build your own website or app using it? Go ahead!

Modify It: Change the code however you like. Customize the design, add new features, or tweak it to fit your project’s needs.

Share It: Feel free to share the original or your modified version with others. You can even sell what you create, whether it’s just the code or a whole new product built on top of it.

Keep It Legal: Just make sure you include the original license and give credit to the original creator when you share or distribute it. That’s all you need to do to stay compliant.

Do Your Own Thing: You can include the code in your project even if it’s licensed differently. You don’t have to stick to the MIT License for your whole project as long as you keep the original part credited.

No Worries About Liability: The code comes as-is, so if there are bugs or issues, it’s on you, not the original creator.
